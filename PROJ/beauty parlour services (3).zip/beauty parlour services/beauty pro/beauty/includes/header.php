<link rel="stylesheet"  href="includes/style.css">
 <div class="navbar"> 
  <img  src="images/logo.jpeg"  class="logo" />
  <nav >
      <ul>
	     
         <li><a href="index.php" style="color:black">Home</a></li>
         <li><a href="services.php" style="color:black">Services</a></li>
         <li><a href="about.php" style="color:black">About</a></li>
         <li><a href="contact.php" style="color:black">Contact</a></li>
         <li><a href="admin/index.php" style="color:black">Admin</a></li>
      </ul>
  </nav>
  <a href="shopping-cart/index.php"><img  src="images/cart.png"  class="cart" /> </a>
  </div><br><br><br>