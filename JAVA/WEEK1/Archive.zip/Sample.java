import java.util.*;


class Sample {
    public static void main(String args[]) {
        for(String i : args) {
            System.out.println(i);
        }
    }
}